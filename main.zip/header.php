<html>
<head>
</head>
<body>


<header role="banner" id="fh5co-header">
			<div class="container">
				<!-- <div class="row"> -->
			    <nav class="navbar navbar-default">
		        <div class="navbar-header">
		        	<!-- Mobile Toggle Menu Button -->
					<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"><i></i></a>
		         <a class="navbar-brand" href="index.php">UAlbany Care Plus</a> 
		        </div>
		        <div id="navbar" class="navbar-collapse collapse">
		          <ul class="nav navbar-nav navbar-right">
		            <li class="active"><a href="#" data-nav-section="home"><span>Home</span></a></li>
		            <li><a href="#" data-nav-section="work"><span>Staff</span></a></li>
		           <!-- <li><a href="#" data-nav-section="testimonials"><span>Testimonials</span></a></li>
		            <li><a href="#" data-nav-section="services"><span>Services</span></a></li>-->
		            <li><a href="#" data-nav-section="about"><span>Developer's</span></a></li>
		            <li><a href="#" data-nav-section="contact"><span>Login</span></a></li>
					<li><a href="#" data-nav-section="login"><span>Contact Us</span></a></li>
					
		          </ul>
		        </div>
			    </nav>
			  <!-- </div> -->
		  </div>
	</header>
	
	</body>
	</html>