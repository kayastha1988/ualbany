            <div class="space">
                <a href="index.php">Patient</a>
                |
                <a href="doctor.php">Doctor</a>
                |
                <a href="manager.php">Admin</a>
            </div>
