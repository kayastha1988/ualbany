<html>
<head>
<link type="text/css" rel="stylesheet" href="styles.css" />
</head>
<body>
<br>
<br>
<form align="center" class="login_form" method="post" action="chatscreen.php">
<div>Username: <input type="text" name="username" /></div><br>
 
<div>Password:  <input type="password" name="password" /></div><br>
<div><input type="submit" value="Login" name="Login" /></div>
</form>

</body>
</html>