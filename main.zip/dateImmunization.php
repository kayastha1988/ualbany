

<?php
error_reporting(0);
session_start();

?>
<!DOCTYPE html>
<html>
<head>
<title> Book an appointment </title>
</head>


<body>


<br><br><br>
<form action="ImmuTime.php" method="post" align="center">
Select a date for appointment : 
<input type="date" name="appointment"required><br><br>

<input type="submit" value="N E X T">
</form>


</body>
</html>   