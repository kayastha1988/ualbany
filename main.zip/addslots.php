 


<html>
<head>
</head>
<body>
</br>
</br>
<form method="post" action="slots.php" align="center">

Add time : <input type="int" name="time"><br/></br>
Add Date : <input type="date" name="date"><br/></br>

<input type="submit" value="Submit" id="startnext">  </br>

</form>

</body>
</html>